import sys
import csv
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

print('input file :',sys.argv[1])
input_file = open(sys.argv[1],"r");

data = csv.reader(input_file)

pmt_id=[]
q=[]
t=[]
x=[]
y=[]
z=[]

nhits = 0
q_sum = 0.
q_avg = 0.


for row in data:
    if (('#' not in row[0])&(len(row)>1)):
        pmt_id.append(int(row[0]))
        q.append(float(row[1]))
        q_sum += float(row[1])
        t.append(float(row[2]))
        x.append(float(row[3]))
        y.append(float(row[4]))
        z.append(float(row[5]))

nhits = len(pmt_id)
q_avg = q_sum/float(nhits)

q_disp = []

for q_val in q:
    if (q_val > q_avg*3.):
        q_disp.append(q_avg*3.)
    else:
        q_disp.append(q_val)

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.scatter(x,y,z,s=3,c=q_disp,cmap='coolwarm')
plt.show()
